//
//  IDisplay.swift
//  Day9_StudentExample
//
//  Created by moxDroid on 2017-10-04.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import Foundation

protocol IDisplay {
    func display()
    func welcome(name:String)
}
