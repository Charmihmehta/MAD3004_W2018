//: Playground - noun: a place where people can play
//Pritesh Patel
import UIKit

class Employee{
    var eid:Int?
    var ename:String?
    var salary:Double?
    //Default Constructor
    init()
    {
        self.eid = 0
        self.ename = String()
        self.salary = 0.0
    }
    //Parametrize Constructor
    init(employeeId eid:Int, employeeName ename:String, employeeSalary salary:Double)
    {
        self.eid = eid
        self.ename = ename
        self.salary = salary
    }
    
   
    convenience init(emp:Employee)
    {
        self.init(employeeId: emp.eid!, employeeName: emp.ename!, employeeSalary: emp.salary!)
    }
    
    func display()
    {
        print(self.eid!, self.ename!, self.salary!)
    }
    
    //Destructor
    deinit {
        print("Employee Object Destroyed")
    }
}

var e1 = Employee()
//Employee.display(e1)
//print(e1.eid!, e1.ename!, e1.salary!)
e1.display()

var e2 = Employee(employeeId: 1, employeeName: "Pritesh Patel", employeeSalary: 5000.0)
e2.display()

e1 = e2
e2 = e1
var e3 = e2
e3.display()

var e4 = Employee(emp: e1)
e4.ename="Subham"
e4.display()

e3.display()

var e5 = e3
e5.ename="Payal"
e5.display()

e3.display()
/*
var eid = Int()
var gender = Bool()
var enm = String()
var salary = Double()
print(eid, gender, enm, salary)
*/

