//: Playground - noun: a place where people can play
//Pritesh Patel
import UIKit

class Employee{
    var eid:Int?
    var ename:String?
    var salary:Double?
    //Default Constructor
    init()
    {
        self.eid = 0
        self.ename = String()
        self.salary = 0.0
        print("(c) Employee")
    }
 
    //Parametrize Constructor
    init(employeeId eid:Int, employeeName ename:String, employeeSalary salary:Double)
    {
        self.eid = eid
        self.ename = ename
        self.salary = salary
    }
    /*
    init(emp:Employee)
    {
        self.eid = emp.eid
        self.ename = emp.ename
        self.salary = emp.salary
    }
 */
    
    func display()
    {
        print(self.eid!, self.ename!, self.salary!)
    }
    
    final func display(welcome:String) {
        print("\(welcome), Welcome to Employee")
    }
    
    //Destructor
    deinit {
        print("Employee Object Destroyed")
    }
}

class FullTimeEmployee : Employee
{
    var noOfPayedLeaves: Int?
    override init()
    {
        
        print("(c) Full Time Employee")
        noOfPayedLeaves = 0
        super.init()
    }
    
    //Parametrize Constructor
    init(employeeId eid:Int, employeeName ename:String, employeeSalary salary:Double, noOfPayedLeaves:Int)
    {
        //super.init()
        super.init(employeeId: eid, employeeName: ename, employeeSalary: salary)
        self.noOfPayedLeaves = noOfPayedLeaves
    }
    
    //Error - Instance method overrides a 'final' instance method
    //override func display(welcome:String) {
    //    print("\(welcome), Welcome to Fulltime family")
    //}
    
    override func display() {
        super.display()
        print("No. of leaves : \(self.noOfPayedLeaves)")
    }
}

var f1 = FullTimeEmployee(employeeId: 1, employeeName: "Pritesh Patel", employeeSalary: 5000.0, noOfPayedLeaves: 12)

f1.display()

//var f2 = FullTimeEmployee(employeeId: 1, employeeName: "Pritesh Patel", employeeSalary: 5000.0
//var e1 = Employee()
//Employee.display(e1)
//print(e1.eid!, e1.ename!, e1.salary!)
//e1.display()

var e2 = Employee(employeeId: 2, employeeName: "Subham", employeeSalary: 6000.0)
e2.display()

//e1 = e2
//e2 = e1
//var e3 = e2
//e3.display()

//var e4 = Employee(emp: e1)
//e4.ename="Subham"
//e4.display()

//e3.display()

//var e5 = e3
//e5.ename="Payal"
//e5.display()

//e3.display()
/*
 var eid = Int()
 var gender = Bool()
 var enm = String()
 var salary = Double()
 print(eid, gender, enm, salary)
 */


